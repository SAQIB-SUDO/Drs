# FullTrackMVP - Android project skeleton (MVP)

This repository contains a minimal Android Studio project skeleton implementing CameraX preview, an ImageAnalysis pipeline stub, placeholders for TensorFlow Lite detection, a simple tracker, and a left-side metrics panel UI.

## Important: I cannot build a signed APK in this environment
I was asked to provide an APK file, but this environment cannot run the Android SDK / Gradle toolchain to produce a real APK. Instead, I created this complete Android Studio project skeleton you can open and build locally with Android Studio (Windows/Mac/Linux) or via GitHub Actions.

## How to build an APK locally (recommended)
1. Install Android Studio (Arctic Fox or newer) and the Android SDK with API 34.
2. Open this project in Android Studio (`File -> Open` and choose the `app` directory or project root).
3. Place your TFLite model at `app/src/main/assets/model.tflite` (create `assets` directory in `app/src/main`).
4. Sync Gradle; set Kotlin & Gradle plugin versions if prompted.
5. Build -> Build Bundle(s) / APK(s) -> Build APK(s). Android Studio will produce an APK under `app/build/outputs/apk/`.

## What you'll need to complete the MVP
- A trained TFLite model for ball detection `model.tflite` or integrate a detector implementation in `TFLiteHelper`.
- Optional: OpenCV or native code for calibration/triangulation (instructions below).
- Optional: Convert YOLOv8 to TFLite with dynamic/static input shape. Use the TF conversion docs or Roboflow export.

## Notes & next steps
- The Kotlin code uses CameraX and ViewBinding. The `processImage` function in `MainActivity` is the entrypoint for model inference per-frame.
- Calibration is currently a placeholder; for accurate pitch->world mapping you'll need a camera calibration flow (use OpenCV `calibrateCamera` and `solvePnP`).
- Multi-phone synchronization is out of scope for this skeleton but can be implemented by timestamped recordings and clap-based alignment.

## If you want, I can:
- Provide full detailed steps to convert a YOLOv8 model to TFLite and how to quantize for mobile.
- Add a GitHub Actions workflow to build an unsigned APK automatically (you will still need to sign it locally).
- Expand the app skeleton to include a runnable (but simplified) CPU-based ball detector using color/contour heuristics for quick testing.

---
