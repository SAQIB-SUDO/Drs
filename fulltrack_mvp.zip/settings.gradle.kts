rootProject.name = "FullTrackMVP"
include(":app")
