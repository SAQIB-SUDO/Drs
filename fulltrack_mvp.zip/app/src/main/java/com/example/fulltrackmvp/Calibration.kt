package com.example.fulltrackmvp

object Calibration {
    // Simple pixel-to-meter scale placeholder. Replace with real calibration.
    var metersPerPixel = 0.005f // default: 0.5 cm per pixel (example)

    fun pixelToWorld(x: Float, y: Float): Pair<Float, Float> {
        return Pair(x * metersPerPixel, y * metersPerPixel)
    }
}
