package com.example.fulltrackmvp

object Tracker {
    // Very lightweight placeholder for Kalman + data association
    data class TrackPoint(val x: Float, val y: Float, val frame: Long)

    private val buffer = mutableListOf<TrackPoint>()

    fun update(detections: List<Detection>, frameTime: Long): TrackPoint? {
        // Simple: take highest-score detection center
        val best = detections.maxByOrNull { it.score } ?: return null
        val cx = best.x + best.w/2f
        val cy = best.y + best.h/2f
        val tp = TrackPoint(cx, cy, frameTime)
        buffer.add(tp)
        if (buffer.size > 200) buffer.removeAt(0)
        return tp
    }

    fun getBuffer() = buffer.toList()
}
